<!-- <!DOCTYPE html>
<html>
<head>
	
</head>
<body>
	
<header>
<div class="left">
	<img class="logo" src="Uploads/Digital_medical.jpg" alt="Profile Picture"> 
</div>
<br><br>
<div class="right">
	<a href="welcome.php">Home</a>
	<a href="login.php">Login</a>
	<a href="Signup.php">Registration</a>
</div>
</header>
<br><br> 
<hr>

</body>
</html>



////////////////////// -->
<!DOCTYPE html>
<html>
<head>
	
</head>
<body>
	
<header>
<div class="container-fluid">
  <div class="container">
    <nav class="navbar navbar-expand-sm navbar-dark bg-primary padding" style="padding: 15px 15px">
      <div class="col-xl-10 col-lg-9 col-md-8 col-sm-7 col-12"><img class="logo" style="width: 120px" src="Uploads/Digital_medical.jpg" alt="Profile Picture">
      </div>
  <!-- 
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button> -->
  <div class="col-xl-2 col-lg-3 col-md-6 col-sm-5 col-12">
    <div class="navbar-nav">
      <a class="nav-link" href="welcome.php" style="color:Tomato;">Home</a>
      <a class="nav-link" href="login.php" style="color:Tomato;" >Login</a>
      <a class="nav-link" href="Signup.php"style="color:Tomato;" >Registration</a>
    </div>
  </div>
</nav>
  </div>
</div>
</header>
<br>
</body>
</html>